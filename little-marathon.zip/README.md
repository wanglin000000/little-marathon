# Little Marathon - 幼儿园小小马拉松活动应用

第一届小小马拉松北京幼师实验幼儿园定州园

## 功能特性

- 扫码即可参与，无需注册
- 头像上传（拍照/相册）
- 59:59 倒计时马拉松
- 3000步目标挑战
- 7个趣味打卡点
- 电子奖杯成就系统
- 一键分享朋友圈

## 访问方式

项目部署在 GitHub Pages，访问地址：
https://[your-username].github.io/little-marathon/

## 本地运行

```bash
python3 -m http.server 8080
# 然后访问 http://localhost:8080
```
